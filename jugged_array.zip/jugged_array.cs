﻿class Program
{
    static void Main(string[] args)
    {
        int[][] a = new int[2][];
        a[0] = new int[] { 1, 2, 3 };
        a[1] = new int[] { 4, 5, 6, 7 };

        for (int i = 0; i < a.Length; i++)
        {
            for (int j = 0; j < a[i].Length; j++)
            {
                Console.Write(a[i][j] + "");
            }
            Console.WriteLine();
        }
        Console.Read();
    }
}
